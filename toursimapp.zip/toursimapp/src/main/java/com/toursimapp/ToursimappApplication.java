package com.toursimapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToursimappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToursimappApplication.class, args);
	}

}
