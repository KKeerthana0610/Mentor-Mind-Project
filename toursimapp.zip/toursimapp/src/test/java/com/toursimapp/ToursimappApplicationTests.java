package com.toursimapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToursimappApplicationTests {

	@Test
	void contextLoads() {
	}

}
